

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-sm-offset-2 col-sm-8">
            
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Products list
                    
                
                    <div class="panel-body">
                    <?php if(count($products) > 0): ?>
                        <table class="table table-striped task-table">
                            <thead>
                                <th>Name</th>
                                <th>Title</th>
                                <th>Category</th>
                                <th>Stock</th>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="table-text"><div><?php echo e($product['name']); ?></div></td>
                                        <td class="table-text"><div><?php echo e($product['title']); ?></div></td>
                                        <td class="table-text"><div><?php echo e($product['category']['name']); ?></div></td>
                                        <?php if($product['stock'] > 0): ?>
                                        <td class="table-text"><div><?php echo e($product['stock']); ?></div></td>
                                        <?php endif; ?>
                                        <?php if($product['stock'] == 0): ?>
                                        <td class="table-text"><div>OUT OF STOCK</div></td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                        <?php if(count($products) == 0): ?>
                        <div class="table table-striped task-table">
                        NO RECORD FOUND
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/products.blade.php ENDPATH**/ ?>