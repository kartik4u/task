<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Response;
use App\Product;
use App\Http\Requests\StockUpdateRequest;




class ProductController extends Controller
{


    //list of products

    function index(){
        $products = Product::select('*')->with(
            ['category'])->paginate(10)->toArray();
        return view('products', [
            'products' => $products['data']
        ]);
    }




    /**
     * Show a list of all  products.
     *
     * @return \Illuminate\Http\Response
     */
    public function getProducts()
    {
        $products = Product::select('*')->with(
        ['category'])->paginate(10)->toArray();

        $res['status'] = 200;
        $res['message']=$products['total']>0?"success.":"No Record Found.";
        $res['data'] =$products['total']>0?$products:(object) [];
        return Response::json($res);
    }


    /**
     * Update Stock
     *
     * @return \Illuminate\Http\Response
     */
    public function updateStock(StockUpdateRequest $request)
    {
        $requested_data = $request->all();
        $product_data= Product::where('id',$requested_data['product_id'])->first();

        Product::where('id',$requested_data['product_id'])->update(['stock'=>$requested_data['stock_value']]);        
        $res['status'] = 200;
        $res['message']=$product_data?"Stock Updated successfully.":"INVALID PRODUCT ID";
        $res['data'] =$product_data;
        return Response::json($res);
    }


}