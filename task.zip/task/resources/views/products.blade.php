@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="col-sm-offset-2 col-sm-8">
            
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Products list
                    
                
                    <div class="panel-body">
                    @if (count($products) > 0)
                        <table class="table table-striped task-table">
                            <thead>
                                <th>Name</th>
                                <th>Title</th>
                                <th>Category</th>
                                <th>Stock</th>
                            </thead>
                            <tbody>

                                @foreach ($products as $product)
                                    <tr>
                                        <td class="table-text"><div>{{ $product['name'] }}</div></td>
                                        <td class="table-text"><div>{{ $product['title'] }}</div></td>
                                        <td class="table-text"><div>{{ $product['category']['name'] }}</div></td>
                                        @if ($product['stock'] > 0)
                                        <td class="table-text"><div>{{ $product['stock'] }}</div></td>
                                        @endif
                                        @if ($product['stock'] == 0)
                                        <td class="table-text"><div>OUT OF STOCK</div></td>
                                        @endif
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        @endif
                        @if (count($products) == 0)
                        <div class="table table-striped task-table">
                        NO RECORD FOUND
                        </div>
                        @endif
                    </div>
                </div>
        </div>
    </div>
@endsection
